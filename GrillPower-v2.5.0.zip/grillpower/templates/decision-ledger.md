# Decision ledger

Project:
Goal:
Revision:
Current round / next question number:
Current phase: inspect / grill / approval / build / verify / stop

| ID | Decision | Evidence/confidence | Frozen options and recommended letter | Answer | Status | Dependencies | Acceptance ID |
|---|---|---|---|---|---|---|---|
| D01 | | observed / inferred / unknown | | | open | | A01 |

Preserve pending option text and labels verbatim. Record the round that displayed them. Retire changed questions visibly; assign a new ID rather than reusing old letters. Compress settled rows without losing acceptance IDs or evidence.

## Shared vocabulary

| Term | Agreed definition |
|---|---|
| | |

## Scope and non-goals

- Confirmed:
- Excluded:
- Constraints and budget:

## Acceptance and evidence

| ID | Required outcome | Verification method | Result | Evidence |
|---|---|---|---|---|
| A01 | | | unrun | |

## Handoff

- Design approval: pending / explicitly approved (record actual approval reference)
- Deferred / blocked decisions:
- Current task:
- Changed files / artifacts:
- Next question batch or action:
