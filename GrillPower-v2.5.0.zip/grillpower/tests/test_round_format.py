import unittest
from tools.check_round import check_round

def round_text(start=1, count=5):
    return "\n\n".join(
        f"**Q{i} — Decision {i}**\n- A. Keep existing\n- B. Extend **(Recommended)**\n- C. Replace\n\nWhy: scoped change."
        for i in range(start, start + count)
    )

class RoundFormatTests(unittest.TestCase):
    def test_five_valid(self):
        self.assertEqual(check_round(round_text()), [])
    def test_later_round(self):
        self.assertEqual(check_round(round_text(6)), [])
    def test_short_final_round(self):
        self.assertEqual(check_round(round_text(count=2), 2), [])
    def test_wrong_count(self):
        self.assertTrue(check_round(round_text(count=4)))
    def test_duplicate_id(self):
        self.assertTrue(check_round(round_text().replace("Q2 —", "Q1 —")))
    def test_skipped_id(self):
        self.assertTrue(check_round(round_text().replace("Q3 —", "Q8 —")))
    def test_missing_recommendation(self):
        self.assertTrue(check_round(round_text().replace("**(Recommended)**", "", 1)))
    def test_multiple_recommendations(self):
        self.assertTrue(check_round(round_text().replace("A. Keep existing", "A. Keep existing (Recommended)", 1)))
    def test_repeated_marker(self):
        self.assertTrue(check_round(round_text().replace("**(Recommended)**", "(Recommended) (Recommended)", 1)))
    def test_bad_letters(self):
        self.assertTrue(check_round(round_text().replace("C. Replace", "B. Replace", 1)))
    def test_too_few_choices(self):
        self.assertTrue(check_round("**Q1 — Test**\n- A. Keep (Recommended)", 1))
    def test_duplicate_text(self):
        self.assertTrue(check_round(round_text().replace("C. Replace", "C. Keep existing", 1)))
    def test_fenced_example_ignored(self):
        self.assertEqual(check_round("~~~\n"+round_text()+"\n~~~\n"+round_text()), [])
    def test_recommended_position(self):
        self.assertEqual(check_round("### Q6: Test\n- A. Old\n- B. New\n- C. Extend (Recommended)",1), [])
    def test_bad_count_argument(self):
        with self.assertRaises(ValueError):
            check_round("",0)

if __name__ == "__main__":
    unittest.main()
