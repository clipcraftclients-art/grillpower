"""Optional offline format check; does not evaluate semantic correctness."""
import argparse
import re
from pathlib import Path

HEADING = re.compile(r"^\s*(?:#{1,6}\s+)?(?:\*\*)?Q([1-9]\d*)\s*[—–:-]\s*(.+?)\s*$")
OPTION = re.compile(r"^\s*[-*]\s+([A-D])\.\s+(.+?)\s*$")
MARKER = re.compile(r"\(Recommended\)", re.I)

def check_round(text, count=5):
    if not 1 <= count <= 5:
        raise ValueError("count must be between 1 and 5")
    questions = []
    errors = []
    fence = None
    for line in text.splitlines():
        stripped = line.lstrip()
        if stripped.startswith((chr(96)*3, "~~~")):
            marker = stripped[0]
            if fence is None:
                fence = marker
            elif fence == marker:
                fence = None
            continue
        if fence:
            continue
        head = HEADING.match(line)
        if head:
            questions.append((int(head[1]), []))
            continue
        opt = OPTION.match(line)
        if opt and questions:
            questions[-1][1].append((opt[1], opt[2]))
    if len(questions) != count:
        errors.append(f"Expected {count} questions; found {len(questions)}.")
    ids = [q for q, _ in questions]
    if ids and ids != list(range(ids[0], ids[0] + len(ids))):
        errors.append("Question IDs must be unique and consecutive.")
    for q, options in questions:
        letters = [letter for letter, _ in options]
        if not 2 <= len(options) <= 4:
            errors.append(f"Q{q}: expected 2-4 options.")
        if letters != list("ABCD"[:len(letters)]):
            errors.append(f"Q{q}: expected consecutive option letters.")
        labels = sum(len(MARKER.findall(value)) for _, value in options)
        if labels != 1:
            errors.append(f"Q{q}: expected exactly one Recommended label; found {labels}.")
        normalized = [" ".join(MARKER.sub("", value).strip("*_ ").lower().split()) for _, value in options]
        if any(not value for value in normalized):
            errors.append(f"Q{q}: empty option.")
        if len(set(normalized)) != len(normalized):
            errors.append(f"Q{q}: duplicate option text.")
    return errors

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("transcript", type=Path)
    parser.add_argument("--count", type=int, choices=range(1, 6), default=5)
    args = parser.parse_args()
    try:
        errors = check_round(args.transcript.read_text(encoding="utf-8"), args.count)
    except (OSError, UnicodeError) as exc:
        parser.error(str(exc))
    for error in errors:
        print(error)
    if not errors:
        print("PASS: round format only; semantic quality remains unverified.")
    return int(bool(errors))

if __name__ == "__main__":
    raise SystemExit(main())
