from pathlib import Path
import re
import sys

root = Path(__file__).resolve().parent
def read(path):
    try:
        return (root / path).read_text(encoding="utf-8")
    except OSError:
        return ""

s = read("SKILL.md")
p = read("PROMPT.md")
r = read("README.md")
m = re.match(r"^---\nname: ([a-z0-9]+(?:-[a-z0-9]+)*)\ndescription: ([^\n]+)\n---\n", s)
body = s[m.end():] if m else ""
required = (
    "README.md", "COMPATIBILITY.md", "CHANGELOG.md", "CONTRIBUTING.md",
    "examples/README.md", "templates/decision-ledger.md",
    "references/deep-review.md", "references/pressure-tests.md", "references/evaluation.md",
    "references/interview.md", "references/delivery.md", "LICENSE",
    "tools/check_round.py", "tests/test_round_format.py",
)
checks = {
    "valid frontmatter": bool(m and m[1] == "grillpower" and 1 <= len(m[2]) <= 1024),
    "skill and prompt identical": bool(body and p == body),
    "deep interview": "five distinct, consequential questions per round" in s and "exactly one Recommended option per question" in s,
    "choice format": all(x in s for x in ("(Recommended)", "all other options neutrally", "actual project", "1A, 2C")),
    "decision quality": all(x in s for x in ("Exclude options that violate hard constraints", "Freeze each question", "retire it visibly", "two lenses within the same pass")),
    "batch preflight": all(x in s for x in ("check each pair of questions", "mutually compatible", "never silently replace", "hard constraints from preferences")),
    "usage discipline": all(x in s for x in ("Reuse inspected evidence", "one shared plan and review", "compress settled decisions")),
    "batch adaptation": all(x in s for x in ("Q1–Q5", "Accept partial replies", "fewer than five", "not approval to implement")),
    "actual approval gate": "No implementation before the user approves" in s and "Wait." in s,
    "capability fallback": all(x in s for x in ("Conversation only", "Read-only", "Editing without execution", "Editing plus execution")),
    "noninteractive safety": "If interactive replies are unavailable" in s and "do not simulate user answers" in s,
    "decision recovery": "On resumption" in s and "decision ledger" in s,
    "no automatic loops": "No automatic improvement cycles" in s and not re.search(r"up to\s+15", s, re.I),
    "bounded repairs": "two unsuccessful attempts" in s and "Repair only concrete defects" in s,
    "evidence traceability": "acceptance IDs" in s and "mark it unrun" in s,
    "required files": all(read(x) for x in required),
    "install visibility": "npx skills add clipcraftclients-art/grillpower --skill grillpower" in r,
    "benchmark honesty": "remain unmeasured" in r and "not a completed benchmark" in read("references/evaluation.md"),
    "no mandatory extra tools": "no mandatory extra tools" in s,
    "five example recommendations": len(re.findall(r"^\*\*Q[1-5] —", r, re.M)) == 5 and all(block.count("(Recommended)") == 1 for block in re.split(r"(?=^\*\*Q[1-5] —)", r, flags=re.M)[1:]),
}

# Check relative Markdown links in all package documents; skip URLs and anchors.
missing = []
for doc in sorted(root.rglob("*.md")):
    if ".git" in doc.relative_to(root).parts:
        continue
    for target in re.findall(r"\[[^\]\n]+\]\(([^()\s]+)\)", doc.read_text(encoding="utf-8")):
        path = target.split("#", 1)[0]
        if not path or "://" in path or path.startswith(("mailto:", "data:")):
            continue
        if not (doc.parent / path).exists():
            missing.append(f"{doc.relative_to(root)}: {target}")
checks["relative links resolve"] = not missing

for name, ok in checks.items():
    print(("PASS" if ok else "FAIL") + " " + name)
for item in missing:
    print("MISSING " + item)
print(f"{sum(checks.values())}/{len(checks)} static checks passed")
sys.exit(0 if all(checks.values()) else 1)
